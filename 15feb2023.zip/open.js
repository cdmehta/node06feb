const fs=require('fs');
fs.open("test3.txt","w",function(err,data){
    if(err) console.log("Error in File "+err);
})

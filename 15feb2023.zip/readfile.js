const fs=require('fs');
fs.readFile("test.txt",function(err,data){
    if(err) console.log("Error in File "+err);
    else console.log("File Data-- "+data.toString());
})

const fs=require('fs');
fs.writeFile("test4.txt","TOPS",function(err){
    if(err) throw err;
});

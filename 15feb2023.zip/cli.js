var arg=process.argv;
const res=parseInt(arg[2])+parseInt(arg[3]);
console.log(res);
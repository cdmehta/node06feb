const fs=require('fs');
fs.rename("test4.txt","test5.txt",function(err){
    if(err)throw err;
})

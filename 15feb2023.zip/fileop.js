const yargs=require('yargs')(process.argv.slice(2)).argv;
const fs=require('fs');
// 1. readfile  read
// 2. deletefile delete
// 3. renamefile rename
// console.log("Choice ="+yargs.choice);
if(yargs.choice=="read")
{
    fs.readFile("test.txt",function(err,data){
        if(err) console.log("Error in File "+err);
        else console.log("File Data-- "+data.toString());
    })
}
else if (yargs.choice=="delete")
{
    fs.unlink("jsondata.js",function(err){
        if(err)throw err;
    })
    
}
else if (yargs.choice=="rename")
{
    fs.rename("test.txt","test10.txt",function(err){
        if(err)throw err;
    })
    
}
const yargs=require('yargs')(process.argv.slice(2)).argv;
console.log("Percentage="+yargs.per);
const p=yargs.per;
if(p>=70)
    console.log("Distinction");
else if(p>=60 && p<=69)
    console.log("First Class");
const yargs=require('yargs')(process.argv.slice(2)).argv;
console.log(yargs.a);
console.log(yargs.b);
console.log(yargs.a+yargs.b);

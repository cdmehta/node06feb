const fs=require('fs');
fs.appendFile("test1.txt","TOPS",function(err,data){
    if(err) console.log("Error in File "+err);
})

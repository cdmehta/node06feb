function printfname(){
    console.log("Chirag");
    
}
function printlname(){
    console.log("Mehta");
}
// setTimeout(() => {
//     printfname();
//     printlname();
// }, 5000);
setTimeout(() =>{
    printfname();
},5000);
setTimeout(() =>{
    printlname();
},2000);
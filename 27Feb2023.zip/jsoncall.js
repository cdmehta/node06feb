const request = require('request')

const url = 'https://fakestoreapi.com/products/'

// const url="data.json"

request({ url: url,json:true }, (error, response) => {
    const data = JSON.parse(response.body)
    console.log(data.name[0])
})
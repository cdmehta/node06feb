const http = require('http');
const request=require('request');
const url='';
request({url:url,json:true},(error,Response)=>{
    const data=JSON.parse(Response.body)
})
const port=process.env.PORT || 3000;

const server=http.createServer((req,res)=>{
 res.statusCode=200; //OK

 res.end(`<b>${data.title[0]}</b>`);
})
server.listen(port,()=>{
console.log('Server is listeining on port ${port}');
});


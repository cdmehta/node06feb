function printfname(callback){
    console.log("Chirag");
    callback();
}
function printlname(){
    console.log("Mehta");
}
setTimeout(() => {
    printfname(printlname);
}, 5000);
// setTimeout(printfname,5000);
// printlname();
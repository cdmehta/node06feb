const request = require('request');
var URL="https://fakestoreapi.com/products/";
request(URL,(error,response,body)=>{
    if(error)console.log(error);
    console.log(response.statusCode);
    console.log(body);
})
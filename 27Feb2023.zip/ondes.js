// Object Destructiring
// const studdata={
//     "fname":"Chirag",
//     "lname":"Mehta",
//     "cell":"9913776671"
// }
// const {fname,lname,cell}=studdata;
// console.log(fname);

//Array Destructiring
const marks=[80,60,90,100,75];
const [html,css,js,node,react]=marks;
console.log(html);
// function printfirstname(fname){
//     console.log("My Name is "+fname);
// }
// function printlastname(lname){
//     console.log("My Name is "+lname);
// }
//  printfirstname("PRavin");
//  printlastname("Katariya");



// function printfirstname(fname,callback){
//     console.log("My Name is "+fname);
//     callback("Katariya");
// }
// function printlastname(lname){
//     console.log("My Name is "+lname);
// }
//  printfirstname("PRavin",printlastname);
 






// function addme(a,b,callback){
//     console.log(a+b);
//     callback();
// }
// function multiplyme(){
//     console.log("Callback function called");
// }
// addme(5,5,multiplyme)


// add
// sub
// mul
// div
add(10,20,sub)
function add(a,b,callback){
    console.log(a+b);
    callback(10,20,mul);
}
function sub(a,b,callback){
    console.log(a-b);
     callback(10,20,mul);
}
function mul(a,b,callback){
    console.log(a*b);
    callback(50,5,div);
}
function div(a,b){
    console.log(a/b);
}


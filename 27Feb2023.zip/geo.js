const request=require("request")
const url='https://api.opencagedata.com/geocode/v1/json?key=1de53c4b468f4708a55ce2fc3d5ccb97&q=surat&pretty=1'
request({url:url,json:true},(error,Response)=>{
var data=Response.body
console.log(data.results[0])
})
const request =require('request');
const URL="https://fakestoreapi.com/products";


const http = require('http');
const port=process.env.PORT || 3000;
const server=http.createServer((req,res)=>{
//  res.setHeader("Content-Type","text/html")
//  res.end('<b>Chirag</b>');

request(URL,(error,Response,body)=>{
    if(error)console.log("Error "+error);
    console.log(Response.statusCode);
    Response.end(body)
})
})
server.listen(port,()=>{
console.log(`Server is listeining on port ${port}`);
});


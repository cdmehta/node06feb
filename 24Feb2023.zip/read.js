const fs = require('fs');

// const dataBuffer = fs.readFileSync('data.json')
// const dataJSON = dataBuffer.toString()
// const user = JSON.parse(dataJSON)
// console.log(user);
// console.log(user.name);
// console.log(user.surname);


const user={
    "name":"Pravin",
    "surname":"Katariya"
}

const userJSON = JSON.stringify(user)
fs.writeFileSync('data.json', userJSON)
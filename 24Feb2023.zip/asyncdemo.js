const async=require('async');
async.parallel(console.log("Demo"),
setTimeout(()=>{
    console.log("time out");
},2000)
)
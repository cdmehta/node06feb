// const data=["Pravin","Surat","NODE"];
// // console.log(data[0]);
// const [name,city,course]=data;
// console.log(n1);

const data={
    "name":"pravin",
    "city":"surat",
    "course":"node"
}
const {name,city}=data;
console.log(name+" "+city);

// Callback JSON data browser API
const fs = require('fs');

const dataBuffer = fs.readFileSync('product.json')
const dataJSON = dataBuffer.toString()
const product = JSON.parse(dataJSON)
// console.log(product);
for(var i =0;i<product.length;i++)
    console.log(product[i].id + " " +product[i].title);
// console.log(product[0].title);
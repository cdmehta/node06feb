const http = require('http');
const fs = require('fs');
const dataBuffer = fs.readFileSync('product.json')
const dataJSON = dataBuffer.toString()
const product = JSON.parse(dataJSON)
// console.log(product);
// console.log(product[0].title);
const port=process.env.PORT || 3000;
const server=http.createServer((req,res)=>{
 res.statusCode=200; //OK
 res.setHeader("Content-Type","text/html")
 for(var i =0;i<product.length;i++)
//  console.log(product[i].id + " " +product[i].title);
 res.end(`<h1>${product[i].id}</h1>`);
})
server.listen(port,()=>{
console.log(`Server is listeining on port ${port}`);
});


const s=[{
    fname:"Chirag",
    lname:"Mehta",
    city:"Surat"
},
{
    fname:"Pravin",
    lname:"Katariya",
    city:"Surat"
},
{
    fname:"Archit",
    lname:"Patel",
    city:"Valsad"
}
]
// const data=s.find(e=>e.fname=="Pravin");
const data=s.find(e=>e.city=="Surat");
console.log(data);
const j='[{"fname":"Chirag","lname":"Mehta","cell":"9913776671"},{"fname":"PRavin","lname":"Katariya","cell":"9988776655"}]';

const data=JSON.parse(j);
console.log(data[1].lname);
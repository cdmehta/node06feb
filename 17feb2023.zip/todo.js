const yargs=require('yargs')(process.argv.slice(2)).argv;

const validator=require('validator');
// console.log(validator.isEmail("pravin@gmail.com"));
// const email="chiragmehta.topsmail.com";
// if(validator.isEmail(email))
//     console.log("Valid");
// else
//     console.log("Invalid");
// console.log(validator.isAlpha("ABC!@#"));
// console.log(validator.isDate("2023/02/30"));
//   console.log(validator.equals("Pravin","pravin"));
// console.log(validator.isLowercase("prAvin"));
// console.log(validator.isMobilePhone("998877665"));
// console.log(validator.isPostalCode("10005","US"));
console.log(validator.isStrongPassword("Uw@885511"));


const express=require('express');
const app=express();
const PORT=5000;

const data={
    "fname":"TOPS",
    "lname":"Technologies"
}

const{fname,lname}=data;
// const str="TOPS"
// const arr=["Pravin","Kaushal","Chirag"];
// const [f1,f2,f3]=arr; //Array Destructuring



// first name is TOPS and Lastname is TEch
{
    const n=10;
    n=12;
    console.log(n);
}

let mydata="<h1>TOPS TECHNOLOGIES</h1><br>";
 mydata+="Ring Road Surat";
mydata+="<body bgcolor=red></body>"
app.get('/',(req,res)=>{
    // res.send(`${str}First Name is ${data.fname} and Last Name is ${data.lname}`);
    // res.send(f2);
    // res.send(fname+" "+lname);
    res.send(mydata);
})



app.listen(PORT,()=>{
    console.log(`Server is running from PORT ${PORT} `);
})
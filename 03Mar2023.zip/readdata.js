const express = require('express');
const https = require('https');
const app = express();

app.get('/api/data', (req, res) => {
  https.get('https://fakestoreapi.com/products/', (response) => {
    let data = '';

    response.on('data', (chunk) => {
      data += chunk;
    });

    response.on('end', () => {
      res.json(JSON.parse(data));
    });
  }).on('error', (error) => {
    console.log(error);
  });
});

app.listen(3000, () => {
  console.log('Server started on port 3000');
});

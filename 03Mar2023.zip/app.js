const express=require('express');
const app=express();
const PORT=5000;
app.get('/',(req,res)=>{
    res.send("<h2>This is my First Express APP</h2>");
})

app.listen(PORT,()=>{
    console.log(`Server is running from PORT ${PORT} `);
})
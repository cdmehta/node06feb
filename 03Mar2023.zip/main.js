const express=require('express');
const app=express();

app.get('/',(req,res)=>{
    res.send("<h1 align='center'>Home Page</h1>");
})
// attributename="value"
app.get('/about',(req,res)=>{
    res.send("<h1>About Us Page</h1>");
})


app.get('/contact',(req,res)=>{
    res.send("<h1>Contact Us Page</h1>");
})

app.listen(5000,()=>{
    console.log("Server Is Running from 5000");
})
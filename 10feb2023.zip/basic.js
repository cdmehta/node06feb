// Programming loop, condition 
// console.log("First Program");
var n=18;
// for(n=1;n<=10;n++)
// {
//     console.log(n);
// }
// if(n%2==0)
//     console.log("Even");
// else   
//     console.log("Odd");
// const a=[12,14,16,12,22,2,5,7,10];
// console.log(a[8]);

// const marks=[55,55,55,55,55];
// const tot=marks[0]+marks[1]+marks[2]+marks[3]+marks[4];
// const per=tot/5;
// if(per>=70)
//     console.log("Distinction");
// else if(per >=60 && per <=69)
//     console.log("First Class");
// else if(per >=50 && per <=59)
//     console.log("Second Class");
// else if(per >=36 && per <=49)
//     console.log("Pass Class");
// else 
//     console.log("Fail");

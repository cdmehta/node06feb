var http = require('http');
var m=require('./Mymodule.js');
//create a server object:
http.createServer(function (req, res) {
  res.write('this is my first program'); //write a response to the client
  console.log("Test");
  m.info("test");
  res.end(); //end the response
}).listen(2000);
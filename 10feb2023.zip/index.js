var LogMod=require("./Log.js");
LogMod.warn("My warn");
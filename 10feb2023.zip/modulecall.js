var m=require('./Mymodule.js');
m.second("2")
const lc=require('lower-case');
const uc= require('upper-case');
console.log(lc.lowerCase("PRAVIN"));
console.log(uc.upperCase("chirag"));

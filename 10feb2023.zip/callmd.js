var m=require('./Mymodule.js');
m.info("Calling...");
m.warnig("Danger");
var print={
    info:function(info)
    {
        console.log("this is info.."+info);
    },
    warnig:function(warning)
    {
        console.log("this is warning.."+warning);
    },
    second:function(second)
    {
        console.log("This is line number is"+second);
    }
} 
module.exports=print;
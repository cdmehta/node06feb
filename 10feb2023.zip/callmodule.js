const uc=require('upper-case');
console.log(uc.upperCase("Chirag"));
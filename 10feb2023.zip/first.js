const http=require('http');
http.createServer(function(req,res){
    res.write("<h1>My First Node Program</h1>");
    res.end();
}).listen(5000);
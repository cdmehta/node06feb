var log={
    info:function(info){
        console.log("My MSG"+info);
    },
    warn:function(warn){
        console.log("My MSG"+warn);
    },
    err:function(err){
        console.log("My MSG"+err);
    }
};
module.exports =log;